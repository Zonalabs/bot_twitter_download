BOT_TOKEN = "123456:ABC-DEF1234ghIkl-zyx57W2v1u123ew11"  # Your telegram bot token
DEVELOPER_ID = 1234567890  # Your telegram id (used for error reporting and private mode)
IS_BOT_PRIVATE = False  # Change this to True to make bot private
